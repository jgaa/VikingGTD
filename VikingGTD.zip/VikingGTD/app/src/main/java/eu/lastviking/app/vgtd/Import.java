package eu.lastviking.app.vgtd;

import android.content.Context;

public interface Import {

	public String GetName();
	public void Import();
}
